import sys


sys.stderr.write('another stderr test from {}\n'.format(__file__))
